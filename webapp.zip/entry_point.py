from app import app

def entry_point():
    return app
